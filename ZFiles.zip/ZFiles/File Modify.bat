@echo off
setlocal DisableDelayedExpansion
cd /d "%~dp0"
title Text File Editor

set "target="
set /p "target=Enter the path of the text file you want to edit: "
if not defined target exit /b
set "target=%target:"=%"

if not exist "%target%" (
    echo File not found.
    pause
    exit /b 1
)

echo.
echo 1 - Add text at the end
echo 2 - Find and replace text
choice /c 12 /n /m "Choose 1 or 2: "
if errorlevel 2 goto replace

set "newText="
set /p "newText=Enter the text to add: "
powershell -NoProfile -Command "$ErrorActionPreference='Stop'; Add-Content -LiteralPath $env:target -Value ([string]$env:newText) -Encoding UTF8"
goto result

:replace
set "oldText="
set "newText="
set /p "oldText=Enter the exact text to find: "
if not defined oldText exit /b
set /p "newText=Enter the replacement text: "
powershell -NoProfile -Command "$ErrorActionPreference='Stop'; $file=Get-Item -LiteralPath $env:target; $text=[IO.File]::ReadAllText($file.FullName); if (-not $text.Contains($env:oldText)) { Write-Host 'Text not found. File unchanged.'; exit 2 }; [IO.File]::WriteAllText($file.FullName, $text.Replace($env:oldText, [string]$env:newText))"

:result
if errorlevel 1 (
    echo No edit completed.
) else (
    echo File saved.
)
pause